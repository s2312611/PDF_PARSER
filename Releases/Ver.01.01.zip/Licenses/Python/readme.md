# Python's License and Copyright

I had no idea if I should preserve a copy of the Python Software Foundation License
(PSFL) and the copyright notice along with the executable file. If I did something
wrong or if you have any advice, please open an issue and/or pull request on GitHub.
