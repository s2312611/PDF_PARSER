Copyright and License Information
---------------------------------

Copyright © 2001 Python Software Foundation.  All rights reserved.
Copyright © 2000 BeOpen.com.  All rights reserved.
Copyright © 1995-2001 Corporation for National Research Initiatives.  All
rights reserved.
Copyright © 1991-1995 Stichting Mathematisch Centrum.  All rights reserved.
See the `LICENSE <https://github.com/python/cpython/blob/main/LICENSE>`_ for
information on the history of this software, terms & conditions for usage, and a
DISCLAIMER OF ALL WARRANTIES.

This Python distribution contains *no* GNU General Public License (GPL) code,
so it may be used in proprietary projects.  There are interfaces to some GNU
code but these are entirely optional.

All trademarks referenced herein are property of their respective holders.

